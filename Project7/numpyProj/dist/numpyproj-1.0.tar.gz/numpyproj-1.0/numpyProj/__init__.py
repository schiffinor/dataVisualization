# numpyProj/__init__.py
from .numpyProj import compute_abs_difference